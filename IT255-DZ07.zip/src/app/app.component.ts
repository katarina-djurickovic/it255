import { Component } from '@angular/core';
import { HotelRoom } from './hotel-room/hotel-room.model';
import { FormGroup, FormBuilder, FormControl, Validators, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  hotels: HotelRoom[];
  newHotel: HotelRoom;
  form: FormGroup;
  room: FormControl;
  price: FormControl;

  constructor(private formBuilder: FormBuilder) {
    this.hotels = [
      new HotelRoom("Dvosobna lux", 150, 10),
      new HotelRoom("Trosobna normal", 160, 22),
      new HotelRoom("Jednosobna", 80, 5)
    ];

    this.form = this.formBuilder.group([{
      'room': new FormControl([Validators.required]),
      'price': new FormControl([Validators.required])
    }]);

    this.form.controls["room"].valueChanges.subscribe((value: string) => {
      if(value.length <= 6){
        console.log("Duzina unete sobe je manja od 6");
      }
    });
  }

  ngOnInit() {
    
  }

  addRoom() {
    if (this.form.valid) {
      this.newHotel = new HotelRoom(this.getRoom(), this.getPrice());
      this.hotels.push(this.newHotel);
    }
  }

  getRoom(){
    return this.form.get("room");
  }

  getPrice(){
    return this.form.get("price");
  }
}
