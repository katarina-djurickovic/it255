import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HotelRoom } from './hotel-room.model';

@Component({
  selector: 'app-hotel-room',
  templateUrl: './hotel-room.component.html',
  styleUrls: ['./hotel-room.component.css']
})
export class HotelRoomComponent implements OnInit {

  @Input() hotels: HotelRoom[];
  @Output() onRoomSelected: EventEmitter<HotelRoom>;

  constructor() {
    this.onRoomSelected = new EventEmitter();
  }

  makeReservation(hotel: HotelRoom) {
    hotel.numOfRes += 1;
  }

  delete(hotel: HotelRoom) {
    const index = this.hotels.indexOf(hotel, 0);
    if (index > -1) {
      this.hotels.splice(index, 1);
    }
  }

  ngOnInit() {
  }

}
