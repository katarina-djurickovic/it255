import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { HotelRoomComponent } from './hotel-room/hotel-room.component';
import { RoomService } from './room-service.service';
import { HotelViewComponent } from './hotel-view/hotel-view.component';

@NgModule({
  declarations: [
    AppComponent,
    HotelRoomComponent,
    HotelViewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [RoomService],
  bootstrap: [AppComponent]
})
export class AppModule { }
