import { Component, OnInit, Input } from '@angular/core';
import { HotelRoom } from '../hotel-room/hotel-room.model';

@Component({
  selector: 'app-hotel-view',
  templateUrl: './hotel-view.component.html',
  styleUrls: ['./hotel-view.component.css']
})
export class HotelViewComponent implements OnInit {

  @Input() hotel: HotelRoom;

  constructor() { }

  ngOnInit() {
  }
}
