import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Hotel } from './interfaces/hotel';
import { Store, select } from '@ngrx/store';
import { HotelState } from './store/state/hotel.state';
import { selectedHotels } from './store/selector/hotel.selector';
import { HotelRoom } from './hotel-room/hotel-room.model';

@Injectable()
export class HotelService{
   public hotels$: Observable<Hotel[]>;

   constructor(private _store: Store<HotelState>){
       this.hotels$ = this._store.pipe(select(selectedHotels));
   }

   public fetchHotels(): Observable<Hotel[]>{
    return new Observable<Hotel[]>();
   }
}