import { initialHotelState } from '../state/hotel.state';
import { HotelActions, EnumHotelAction } from '../actions/hotel.actions';

export function hotelReducer(state = initialHotelState, action: HotelActions){
    switch(action.type){
        case EnumHotelAction.GetHotelsSuccess: {
            return {
                ...state,
                hotels: action.payload
            };
        }
        default: return state;
    }
}