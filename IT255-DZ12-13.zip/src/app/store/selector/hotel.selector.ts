import { createSelector } from '@ngrx/store';

const selectHotels = (state: any) => state.hotel;

export const selectedHotels = createSelector(
    selectHotels,
    (state: any) => { return state.hotels.hotels }
);