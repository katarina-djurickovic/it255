import { Action } from '@ngrx/store'; 
import { Hotel } from '../../interfaces/hotel';
import { type } from 'os';

export enum EnumHotelAction {
    GetHotels = '[Hotel] Get Hotels',
    GetHotelsSuccess = '[Hotel] Get Hotels Success'
}

export class GetHotels implements Action{
    public readonly type = EnumHotelAction.GetHotels;
}

export class GetHotelsSuccess implements Action{
    public readonly type = EnumHotelAction.GetHotelsSuccess;
    constructor(public payload: Hotel[]){}
}

export type HotelActions = GetHotels | GetHotelsSuccess;