import { HotelRoom } from 'src/app/hotel-room/hotel-room.model';

export interface HotelState{
    hotels: Array<HotelRoom>;
}

export const initialHotelState: HotelState = {
    hotels: []
};