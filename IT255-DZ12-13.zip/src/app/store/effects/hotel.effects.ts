import { Injectable } from "@angular/core";
import { Actions, Effect, ofType } from "@ngrx/effects"; 
import { of } from "rxjs"; 
import { HotelService } from 'src/app/room-service.service';
import { GetHotels, EnumHotelAction } from '../actions/hotel.actions';
import { switchMap } from 'rxjs/operators';

@Injectable()
export class HotelEffect{
    constructor(private _actions$: Actions, private _hotelService: HotelService){}

    @Effect()
    getHotels$ = this._actions$.pipe(ofType<GetHotels>(EnumHotelAction.GetHotels),
    switchMap(()=> this._hotelService.fetchHotels()))

}