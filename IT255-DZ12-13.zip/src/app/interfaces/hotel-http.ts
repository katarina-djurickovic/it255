export interface HotelHttp {
    hotels: [];
}
