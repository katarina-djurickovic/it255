export interface Hotel {
    room: string;
    price: number;
    numOfRes: number;
}
