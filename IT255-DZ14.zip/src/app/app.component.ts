import { Component } from '@angular/core';
import { FilterPipePipe } from 'src/app/helpers/filter-pipe.pipe'
import { Video } from './models/video';
import { YoutubeService } from './services/youtube.service';
import { from } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'it255-dz09';
  ar: [] = [];
  public videos: Video[] = [];
  private _links: string[] = ['YiUQE5bJKFU', 'B32yjbCSVpU', 'yG0oBPtyNb0', 'f7McpVPlidc', 'qhZULM69DIw', 'wvUQcnfwUUM'];

  constructor(private service: YoutubeService) {
    
    this.service.getVideos().subscribe(data => {
      this.ar = data["items"];
      
    for (let i = 0; i < 6; i++) {
      console.log(this.ar[i]);
      this.videos.push(new Video("Duration: " + this.ar[i]["contentDetails"]["duration"], "Dimension: " + this.ar[i]["contentDetails"]["dimension"]  , 'https://www.youtube.com/embed/' + this.ar[i]["id"]));
    }
    });
  }

}
