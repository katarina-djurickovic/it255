import { inject, fakeAsync, tick, TestBed } from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';
import { YoutubeService } from './youtube.service';
import { Http, ConnectionBackend, BaseRequestOptions, Response, ResponseOptions } from '@angular/http';


describe('YoutubeService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [BaseRequestOptions, MockBackend, YoutubeService, {
      provide: Http, useFactory: (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) => { return new Http(backend, defaultOptions); }, deps: [MockBackend, BaseRequestOptions]
    }]

  }));

  describe('getVideos', () => {
    it('retrieves using the track ID', 
    inject([YoutubeService, MockBackend], 
      fakeAsync((svc, backend) => { 
        let res; 
        expectURL(backend, 'https://www.googleapis.com/youtube/v3/videos?part=contentDetails&chart=mostPopular&key=AIzaSyAtDFEz9zZlRzwQW9veI4OHi7VGzaVKGsw'); 
        svc.getVideos('TRACK_ID').subscribe((_res) => { res = _res; }); 
        tick(); 
        expect(res.name).toBe(''); })));
  });

  it('should be created', () => {
    const service: YoutubeService = TestBed.get(YoutubeService);
    expect(service).toBeTruthy();
  });
});
