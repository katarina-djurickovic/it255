import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class YoutubeService {

  private YOUTUBE_API_KEY: string = "AIzaSyAtDFEz9zZlRzwQW9veI4OHi7VGzaVKGsw";
  private YOUTUBE_API_URL: string = "https://www.googleapis.com/youtube/v3/videos?part=contentDetails&chart=mostPopular&key=";


  constructor(private http: HttpClient) { }

  public getVideos() {
    return this.http.get(this.YOUTUBE_API_URL + this.YOUTUBE_API_KEY);
  }
}
