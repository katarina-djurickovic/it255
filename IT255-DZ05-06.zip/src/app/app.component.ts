import { Component } from '@angular/core';
import { HotelRoom } from './hotel-room/hotel-room.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  hotels: HotelRoom[];
  newHotel: HotelRoom;

  constructor(){
    this.hotels = [
      new HotelRoom("Dvosobna lux", 150, 10),
      new HotelRoom("Trosobna normal", 160, 22),
      new HotelRoom("Jednosobna", 80, 5)
    ];
  }

  addRoom(room, price){
    this.newHotel = new HotelRoom(room, price);
  }
}
