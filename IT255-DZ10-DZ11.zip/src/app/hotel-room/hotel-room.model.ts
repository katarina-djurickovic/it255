export class HotelRoom {
    room: string;
    price: number;
    numOfRes: number;

    constructor(room, price, numOfRes?){
        this.room = room;
        this.price = price;
        this.numOfRes = numOfRes || 0;
    }
}