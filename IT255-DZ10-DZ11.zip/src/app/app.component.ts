import { Component } from '@angular/core';
import { HotelRoom } from './hotel-room/hotel-room.model';
import { FormGroup, FormBuilder, FormControl, Validators, AbstractControl } from '@angular/forms';
import { RoomService } from './room-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  hotels: HotelRoom[];
  newHotel: HotelRoom;
  form: FormGroup;
  room: FormControl;
  price: FormControl;
  result = 0;

  constructor(private formBuilder: FormBuilder, private service: RoomService) {
    this.hotels = [
      new HotelRoom("Dvosobna lux", 150, 10),
      new HotelRoom("Trosobna normal", 160, 22),
      new HotelRoom("Jednosobna", 80, 5)
    ];

    this.form = this.formBuilder.group([{
      'room': new FormControl([Validators.required]),
      'price': new FormControl([Validators.required])
    }]);

   
  }

  ngOnInit() {
    
  }

  addRoom(room: HTMLInputElement, price: HTMLInputElement) {
    if (this.form.valid) {
      this.newHotel = new HotelRoom(room.value, price.value);
      this.hotels.push(this.newHotel);
    }
  }

  getPriceService(num: HTMLInputElement){
    this.result = this.service.getPrice(+num.value);
  }

  getRoom(){
    return this.form.get("room");
  }

  getPrice(){
    return this.form.get("price");
  }
}
