export class RoomService{
    getPrice(num:number){
        return 50*num;
    }
}